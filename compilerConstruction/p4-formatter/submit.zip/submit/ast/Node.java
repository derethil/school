package submit.ast;

public interface Node {
    void toCminus(StringBuilder builder, final String prefix);
}
