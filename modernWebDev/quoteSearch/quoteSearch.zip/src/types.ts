export interface Quote {
  author: string;
  content: string;
  isRandom?: boolean;
}
